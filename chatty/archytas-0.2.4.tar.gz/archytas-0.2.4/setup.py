# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['archytas']

package_data = \
{'': ['*']}

install_requires = \
['docstring-parser>=0.15,<0.16',
 'openai>=0.27.4,<0.28.0',
 'pytz>=2023.3,<2024.0',
 'rich>=13.3.4,<14.0.0',
 'tenacity>=8.2.2,<9.0.0',
 'toml>=0.10.2,<0.11.0']

entry_points = \
{'console_scripts': ['chat-repl = archytas.repl:start_repl']}

setup_kwargs = {
    'name': 'archytas',
    'version': '0.2.4',
    'description': 'A library for pairing LLM agents with tools so they perform open ended tasks',
    'long_description': '# Archytas: A Tools Interface for AI Agents\n<img src="assets/logo.png" width="150" height="150" align="left" style="padding-right:0.5em;"/>\n\nImplementation of the [ReAct (Reason & Action)](https://arxiv.org/abs/2210.03629) framework for Large Language Model (LLM) agents. Mainly targeting OpenAI\'s GPT-4.\n\nEasily create tools from simple python functions or classes with the `@tool` decorator. A tools list can then be passed to the `ReActAgent` which will automagially generate a prompt for the LLM containing usage instructions for each tool, as well as manage the ReAct decision loop while the LLM performs its task.\n\nTools can be anything from internet searches to custom interpreters for your domain. Archytas provides a few built-in demo tools e.g. datetime, fibonacci numbers, and a simple calculator.\n\n<div style="clear:left;"></div>\n \n# Quicksart\n```bash\n# make sure poetry is installed\npip install poetry\n\n# clone and install\ngit clone git@github.com:jataware/archytas.git\ncd archytas\npoetry install\n\n# make sure OPENAI_API_KEY var is set\n# or set openai_key in .openai.toml\nexport OPENAI_API_KEY="sk-..."\n\n# run demo\npoetry run chat-repl\n```\n\n# Simple Usage\nImport pre-made tools from the tools module\n```python\nfrom archytas.react import ReActAgent, FailedTaskError\nfrom archytas.tools import datetime_tool, fib_n, calculator\n\nfrom easyrepl import REPL\n\n# create the agent with the tools list\nsome_tools = [datetime_tool, fib_n, calculator]\nagent = ReActAgent(tools=some_tools+[mytool], verbose=True)\n\n# REPL to interact with agent\nfor query in REPL()\n    try:\n        answer = agent.react(query)\n        print(answer)\n    except FailedTaskError as e:\n        print(f"Error: {e}")\n```\n\n## Built-in Tools\n(TODO)\n- ask_user\n- datetime\n- timestamp\n- fib_n\n- calculator\n- ...\n\n# Custom Tools\n(TODO)\n```python\nfrom archytas.tools import tool\n\n@tool()\ndef example_tool(arg1:int, arg2:str=\'\', arg3:dict=None) -> int:\n    """\n    Simple 1 sentence description of the tool\n\n    More detailed description of the tool. This can be multiple lines.\n    Explain more what the tool does, and what it is used for.\n\n    Args:\n        arg1 (int): Description of the first argument.\n        arg2 (str): Description of the second argument. Defaults to \'\'.\n        arg3 (dict): Description of the third argument. Defaults to {}.\n\n    Returns:\n        int: Description of the return value\n\n    Examples:\n        >>> example_tool(1, \'hello\', {\'a\': 1, \'b\': 2})\n        3\n        >>> example_tool(2, \'world\', {\'a\': 1, \'b\': 2})\n        4\n    """\n    return 42\n\n# TODO: class tool example\n```',
    'author': 'David Andrew Samson',
    'author_email': 'david.andrew.engineer@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
