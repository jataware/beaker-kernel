# Chatty

## Usage

Make sure you have `openai_key = "sk-..."` set in `.openai.toml` before starting.

Run `poetry run chat` to mess with demo