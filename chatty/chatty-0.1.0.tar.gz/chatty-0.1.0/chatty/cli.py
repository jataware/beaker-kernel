from cmd import Cmd

from colorama import Fore, Back, Style
from archytas.react import ReActAgent

from .controller import Controller

controller = Controller()

class ChattyCLI(Cmd):
    intro = "\n\n-- Welcome to Chatty, your friendly ASKEM lab assistant --\n\n"
    prompt = f"\n\n{Back.LIGHTMAGENTA_EX}{Fore.BLACK}->{Style.RESET_ALL} "
    file = None
    assistant= None

    def default(self, arg):
        if arg == 'EOF':
            print()
            return True
        if arg.strip() == '':
            return
        try:
            if ChattyCLI.assistant is None:
                assistant = ReActAgent(tools=[controller])
            result = ChattyCLI.assistant.react(arg)
            print("\n================\n\n")
            print(f"{Back.LIGHTGREEN_EX}{Fore.BLACK}Query    ->{Style.RESET_ALL} {arg}\n")
            print(f"{Back.LIGHTBLUE_EX}{Fore.BLACK}Response ->{Style.RESET_ALL} {result}")
        except ValueError:
            pass
        finally:
            print()  # Print a newline so prompt is not messed up

    def do_read(self,arg):
        if ChattyCLI.assistant is None:
            assistant = ReActAgent(tools=[controller])
        with open(arg, 'r') as file:
            print(ChattyCLI.assistant.react(file.read()))

def cli():
    ChattyCLI().cmdloop()

def test_script():
    import os
    import sys
    args = sys.argv
    if len(args) <= 1:
        file_name = 'scripts/default.txt'
    else:
        arg = args[1]
        if arg and os.path.exists(arg):
            file_name = arg
        else:
            print(f"Error: file '{arg}' does not exist or is invalid.")
            return

    commands = []
    with open(file_name, 'r') as file:
        commands = [line.strip("\n") for line in file.readlines()]

    assistant = ReActAgent(tools=[controller], verbose=True)
    print(f"-- Testing script `{file_name} on Chatty --`")
    for command in commands:
        print("")
        print(f"{Back.MAGENTA}{Fore.WHITE}YOU:{Style.RESET_ALL}  {command}")
        response = assistant.react(command)
        print(f"{Back.BLUE}{Fore.WHITE}CHATTY:{Style.RESET_ALL}  {response}")
        print("")


