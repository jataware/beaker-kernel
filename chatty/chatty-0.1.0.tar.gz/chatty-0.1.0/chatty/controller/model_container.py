from __future__ import annotations

from requests import get
import json
from pydantic import BaseModel

from chatty.settings import settings

class ModelNotExistError(Exception):
    pass

class ModelContainer(BaseModel):
    tds_url: str = settings.data_service_url
    cached_models: dict | None = None
    
    def get_models(self) -> dict:
        if self.cached_models is not None:
            return self.cached_models
        
        response = get(f"{self.tds_url}/models/descriptions", params={"page_size": 100, "page": 0})
        assert response.status_code == 200
        model_descriptions = response.json()

        models = []

        #get the full model description/parameters/etc. for each model
        for model in model_descriptions:
            id = model["id"]
            response = get(f"{self.tds_url}/models/{id}")
            assert response.status_code == 200
            model = response.json()
            models.append(model)

        # cache the models as map from id to model
        self.cached_models = {int(model["id"]): model for model in models}
        return self.cached_models
  
    
    @property
    def ids(self):
        return [*self.get_models().keys()]

    def __getitem__(self, id:int) -> dict:
        try:
            return self.get_models()[id]
        except KeyError:
            raise ModelNotExistError


    def model_as_str(self, id:int, include_parameters=False):
        model = self[id]
        desc = "\n".join([
            f'name: {model["name"]}',
            f'id: {model["id"]}',
            f'description: {model["description"]}',
            f'framework: {model["framework"]}',
            f'parameters: {model["parameters"]}' if include_parameters else ''
        ])
        return desc
