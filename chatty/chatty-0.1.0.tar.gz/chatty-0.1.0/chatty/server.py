from importlib.metadata import version
from json import dumps

from fastapi import FastAPI, Response, Request
from toml import load
from uvicorn import run
from archytas.react import ReActAgent

from .controller import Controller


controller = Controller()
agent = ReActAgent(tools=[controller])



api = FastAPI(
    title="Chatty",
    version=version("chatty"),
    description="Chatty Server POC",
    docs_url="/"
)

@api.post("/chatty")
async def chat(request: Request) -> Response:
    text = str(await request.body())

    response = agent.react(text)
    return Response(
        headers={
            "content-type": "application/json"
        },
        content=dumps({"chatty": response})
    )


# TODO(five): Add controller endpoint

def server(host:str = "0.0.0.0", port:int = 8082):
    run("chatty.server:api", host=host, port=port, reload=True)
