# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['chatty', 'chatty.controller']

package_data = \
{'': ['*']}

install_requires = \
['archytas>=0.2.3,<0.3.0',
 'chromadb>=0.3.21,<0.4.0',
 'colorama>=0.4.6,<0.5.0',
 'fastapi>=0.95.0,<0.96.0',
 'langchain>=0.0.119,<0.0.120',
 'openai>=0.27.2,<0.28.0',
 'pandas>=2.0.0,<3.0.0',
 'pydantic>=1.10.7,<2.0.0',
 'requests>=2.28.2,<3.0.0',
 'toml>=0.10.2,<0.11.0',
 'uvicorn>=0.21.1,<0.22.0']

entry_points = \
{'console_scripts': ['chat = chatty.cli:cli',
                     'chat-server = chatty.server:server',
                     'test = chatty.cli:test_script']}

setup_kwargs = {
    'name': 'chatty',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Chatty\n\n## Usage\n\nMake sure you have `openai_key = "sk-..."` set in `.openai.toml` before starting.\n\nRun `poetry run chat` to mess with demo',
    'author': 'Five Grant',
    'author_email': '5@fivegrant.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
