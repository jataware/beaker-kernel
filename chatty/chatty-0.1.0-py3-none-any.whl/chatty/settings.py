import os
import toml
from typing import Optional

from pydantic import BaseSettings


class Settings(BaseSettings):
    openai_key: Optional[str] = None
    data_service_url: str = "http://localhost:8001"
    simulation_scheduler_url: str = "http://localhost:8080"


    class Config:
        fields = {}


settings = Settings()

# Try to fetch openai key from config files if they are not found in environment
if not settings.openai_key:
    openai_conf_files = [
        "./.openai.toml",
        "~/.openai.toml",
    ]

    for filepath in openai_conf_files:
        filepath = os.path.expanduser(filepath)
        if os.path.exists(filepath):
            try:
                openai_conf = toml.load(open(filepath))
                openai_key = openai_conf.get('openai_key')
                if openai_key:
                    print(f"found in {filepath}")
                    settings.openai_key = openai_key
                    break
            except IOError:
                pass