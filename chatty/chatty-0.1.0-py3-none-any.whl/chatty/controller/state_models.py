from pandas import DataFrame
from pydantic import BaseModel
from typing import Optional, Any
from textwrap import indent

def with_header(header, content):
    return f"{header}:\n" + indent(content, "\t")

class ModelDefaults(BaseModel):
    initial_state: dict[str, float] = {}
    parameters: dict[str, float] = {}

    def __str__(self):
        content = "\n".join([
            f"initial_state: {self.initial_state}",
            f"parameters: {self.parameters}",
        ])
        return with_header("defaults", content)


class Model(BaseModel):
    name: str
    description: str
    petri: dict[Any, Any]
    defaults: ModelDefaults

    def __str__(self):
        content = "\n".join([
            f"name: {self.name}",
            # f"description: {self.description}",
            # f"petri: {self.petri}",
            f"{self.defaults}"
        ])
        return with_header("model", content)
        

class Run(BaseModel):
    job_id: Optional[int] = None
    # operation: # TODO(five): add operation enum
    operation: str = "forecast"
    model: Model
    initial_state: dict[str, float] = {}
    parameters: dict[str, float] = {}
    tspan: tuple[float, float] = (0, 90.0)
    result: Optional[DataFrame] = None

    class Config:
            arbitrary_types_allowed = True

    def __str__(self):
            content = "\n".join([
                f"job_id: {self.job_id}",
                f"model: {self.model.name}",
                f"initial_state: {self.initial_state}",
                f"parameters: {self.parameters}",
                f"tspan: {self.tspan}",
                f"result: {self.result}"
            ])
            return with_header("run", content)

    def as_scheduler_payload(self):
        return {
            "petri": self.model.petri,
            "initials": self.initial_state,
            "params": self.parameters,
            "tspan": self.tspan,
        }


class SimulationSession(BaseModel):
    model: Optional[Model] = None
    model_overrides: dict[str, float] = {}
    runs: list[Run] = []
    
    def __str__(self):
            content = "\n".join([
                f"{self.model}",
                f"model_overrides: {self.model_overrides}",
                # f"runs: {self.runs}",
            ])
            return with_header("session", content)

    def get_run(self, job_id: int):
        for run in self.runs:
              if run.job_id == job_id:
                   return run
        else:
             return None 

# class Run(BaseModel):
#     job_id : int | None = None
#     operation : str = "forecast" # TODO(five): Make this an enum
#     # TODO(five): Make args work for more than forecast 
#     petri : str | None = None 
#     initials: dict[str, float] = {}
#     params: dict[str, float] = {}
#     tspan: tuple[float, float] = (0, 90.0)
#     result: DataFrame | None = None
#     # settings: dict # TODO(five): Add kwargs setting for SciML (like step size)
    
# class Config:
#         arbitrary_types_allowed = True
    