from io import StringIO
from typing import Optional
import copy
import requests
import time
import os
import warnings

import logging
logging.disable(logging.WARNING)  # Disable warnings

import toml
import json

import pandas as pd
from pydantic import BaseModel, Extra

from langchain.agents import create_pandas_dataframe_agent
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain import OpenAI, VectorDBQA
from langchain.vectorstores import Chroma

from archytas.tools import tool, toolset


from chatty.settings import settings
from . import SimulationSession, Model, ModelDefaults, Run

from .model_container import ModelContainer, ModelNotExistError


logger = logging.Logger(__name__)

@toolset()
class Controller(BaseModel):
    session: Optional[SimulationSession]
    tds_url: str = settings.data_service_url
    sim_scheduler_url: str = settings.simulation_scheduler_url
    _cache: dict= {}
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.reset()

    @property
    def has_started(self) -> bool:
        return self.session is None
    

    @property
    def models(self) -> ModelContainer:
        if "models" in self._cache:
            return self._cache["models"]
        self._cache["models"] = ModelContainer(tds_url=self.tds_url)
        return self._cache["models"]


    def reset(self):
        self.session = SimulationSession()


    @tool()
    def session_state(self)->str:
        """
        Inspect the state of the simulation session. 

        This should be used to answer questions about the simulation, including the values of the current and default parameter values and initial states.
        
        The session state contains the following information:
        1. model: (Optional) A representation of the model with the following fields:
            a. name: The name of the model
            b. description: A human readable description of the model
            c. petri: A serialized JSON representation of a Petri Net model
            d. defaults: A dictionary that contains the default initial states and parameters of the Petri Net model
        2. model_overrides: a dictionary that contains the working changes to the default values of the associated 
           model's initial states and parameters
        3. runs: A list of objects that represent individual runs of the model. The objects have the following format:
            a. job_id: (Optional) The id used to identify the simulation run job
            b. model: A representation of the model that was simulated for the run
            c. initial_state: A dictionary of the initial state of the model used when the run was submitted
            d. parameters: A dictionary of the parameters used when the run was submitted
            e. tspan: A 2-item tuple of floats that represents the start and end values for the timespan the simulation is running for
            f. result: (Optional) A pandas dataframe that contains the results of the simulation run
        
        Returns:
            str: the session state
        """
        # Need to actually track things. Maybe a good idea to split this in to finer tools so certain things can be queried?
        return str(self.session)

    @tool()
    def find_models(self, query: str)->str:
        """
        Finds available models and returns information about them.

        Input is a full grammatically correct question about model(s).
        For example, "What models are available?" or "What is the id of <model name>?"
        Do NOT input single word queries like "SIR". 

        This has the following information available:
        - model name
        - model id
        - model description
        - model framework
        
        Args:
            query (str): A fully grammatically correct quetion about model(s).

        Returns:
            str: Information related to the users query
         """
        #set up the agent
        if "docstore" in self._cache:
            docstore = self._cache["docstore"]
        else:
            texts = [self.models.model_as_str(id) for id in self.models.ids]
            # logging.disable(logging.WARNING)  # Disable warnings from chroma 
            embeddings = OpenAIEmbeddings()
            docstore = Chroma.from_texts(texts, embeddings)
            # logging.disable(logging.NOTSET)  # Re-enable warnings
            
        qa = VectorDBQA.from_chain_type(llm=OpenAI(temperature=0), chain_type="stuff", vectorstore=docstore)
                
        response = qa.run(query)
        return response
    

    @tool()
    def load_model_to_working_state(self, model_id: int)->bool:
        """
        Fetch a model from the api and load it in to the current session state.

        The input is the integer id of the model to load.

        There is no need to take any further action after loading the model to working state.
        
        Look up integer id of model using `find_models`

        Args:
            model_id (int): integer id of the model to load.

        Returns:
            bool: Whether the load was successful
        """
        url = f"{self.tds_url}/models/{model_id}"
        response = requests.get(url)
        if response.status_code  == 200:
            payload = response.json()
            model = Model(
                name=payload.get("name"),
                description=payload.get("description"),
                petri=payload.get("content"),
                defaults=ModelDefaults(
                    parameters={
                        param["name"]: float(param["default_value"])
                        for param in payload["parameters"] if not param["state_variable"]
                    },
                    initial_state={
                        param["name"]: float(param["default_value"])
                        for param in payload["parameters"] if param["state_variable"]
                    },
                ),
            )
            self.session.model = model
            return True
        elif response.status_code == 404:
            raise Exception(f"Model {model_id} does not exist")
        else:
            return False


    @tool()
    def update_model(self, values: dict)->bool:
        """
        Overrides default parameter and initial state values for the model for a subsequent run.

        The input type is a flat object where the key matches one of the existing keys set in initial_state or parameters and the value is the new value as a float.
        All of the key names in model_overrides should match a key that is set in initial_state or parameters and you should correct the
        key name if you can. If you are unable to find a matching key from the defaults, you should fail gracefully.

        Only run this if you want to change the default initial values.
                
        Args:
            values (dict): the values to override (e.g. {"gamma": 0.9})

        Returns:
            bool: Whether the update was successful
        """
        ok_names = set(self.session.model.defaults.initial_state.keys()) | set(self.session.model.defaults.parameters.keys())
        bad_keys = set(values.keys()).difference_update(ok_names)
        if bad_keys:
            raise Exception(f"""Failed. The following keys cannot be used: {", ".join(bad_keys)}.
            All keys must be one of the following: {", ".join(ok_names)}""")
        self.session.model_overrides.update(values)
        return True


    @tool()
    def run_simulation(self) -> int:
        """
        Kick off a simulation job. This automatically uses the built up simulation run.
        Before a simulation is started, a model must
        be selected along by using the 'add model' tool.
    
        A model is run using this command.
    
        Returns a run that contains the results of the simulation.

        Returns:
            int: id of the newly created simulation job
        """

        # Determine initial state and params by fetching defaults then applying overrides
        state_overrides = set(self.session.model.defaults.initial_state.keys()) & set(self.session.model_overrides.keys())
        param_overrides = set(self.session.model.defaults.parameters.keys()) & set(self.session.model_overrides.keys())
        initials = copy.deepcopy(self.session.model.defaults.initial_state)
        initials.update({k: v for k, v in self.session.model_overrides.items() if k in state_overrides})
        params = copy.deepcopy(self.session.model.defaults.parameters)
        params.update({k: v for k, v in self.session.model_overrides.items() if k in param_overrides})

        # TODO: Make tspan settable
        tspan = (0, 90.0)

        run = Run(
            model=copy.deepcopy(self.session.model),
            initial_state=initials,
            parameters=params,
            tspan=tspan,
        )

        # logging.warn(f"\nStarting run with following payload:\n{run.as_scheduler_payload()}")
        call_url = f"{self.sim_scheduler_url}/calls/{run.operation}"
        response = requests.post(call_url, json=run.as_scheduler_payload())
        if response.status_code  == 201:
            job_id = response.json()["id"]
            run.job_id = job_id
            self.session.runs.append(run)

            status_url = f"{self.sim_scheduler_url}/runs/{job_id}/status"
            result_url = f"{self.sim_scheduler_url}/runs/{job_id}/result"

            status = "waiting"
            while status not in ["done", "failure"]:
                time.sleep(0.25)
                status_response = requests.get(status_url)
                status = status_response.json()['status']
            
            if status == "failure": 
                return # TODO(five): Handle better

            result_response = requests.get(result_url)
            csv = result_response.text

            file_name = os.path.abspath(f"./data-{job_id}.csv")
            run.result = pd.read_csv(StringIO(csv))
            run.result.to_csv(file_name, sep=",")
            
            return run.result
        else:
            raise Exception("I encountered some error starting a forecast")
        if run.job_id is None:
            raise Exception("Some failure happened trying to start the sim")
        return run.job_id


    @tool()
    def query_job_run_result_dataframe(self, query: str)->str:
        """
        Query the results of a simulation run.
        
        The input is a sentence that the underlying LLM will use to perform the analysis against a dataframe.
        The dataframe is found in the `result` field of the run in the session state as returned by the session_state action

        This uses the Pandas dataframe langchain agent to perform pandas queries against the dataframe.
        
        If the run results have not been fetched, you should fetch the results before this step.

        This function can be used to generate plots using matplotlib. If a plot is generated, an image file will be saved and the full path of the generated file will be returned.
        
        
        Args:
            query (str): A sentence asking a dataframe related question about the latest run

        Returns:
            str: The result of looking up the query
        """
        # run = self.session.get_run(job_id=job_id)
        run = self.session.runs[-1]
        df_tool = create_pandas_dataframe_agent(OpenAI(temperature=0), run.result, verbose=True)
        response = df_tool.run(query)
        return response


    # @tool()
    # def display_a_plot(self, plot_file_path: str):
    #     """
    #     Input: The full path to a plot image file. 
        
    #     This will be display the image in an external tool and not return any update.
    #     """
    #     print(plot_file_path)
        